#f = open("video_000000000000_keypoints (2).json", "r") 
#Outputs: body key pts. w/ same torso length
import math
#import numpy as np
#from io import StringIO
import json

#data1 = np.genfromtxt('video_000000000000_keypoints (2).json', delimiter = ',')

class Standardization:
  def __init__(self, frame):
    self.frame = frame #aka the raw output from openpose

  {"version":1.3,"people":[{"person_id":[-1],"pose_keypoints_2d":[471.617,69.6872,0.855476,465.063,97.046,0.921653,445.552,94.4856,0.83024,432.419,119.26,0.91495,450.708,129.626,0.851216,483.363,98.3117,0.897775,514.635,99.7439,0.861275,539.478,99.6952,0.865577,455.968,151.928,0.822895,445.553,150.548,0.820881,410.253,166.247,0.828347,442.884,200.184,0.809429,466.364,157.098,0.788914,454.683,204.138,0.861065,452.032,254.954,0.681517,465.126,67.0895,0.954088,474.228,67.0862,0.949122,457.287,69.6688,0.851605,476.826,69.6757,0.363424,446.832,266.735,0.615013,454.667,266.699,0.642995,449.433,256.295,0.501364,442.848,215.829,0.38636,437.668,214.54,0.42225,446.824,198.878,0.526531],"face_keypoints_2d":[],"hand_left_keypoints_2d":[],"hand_right_keypoints_2d":[],"pose_keypoints_3d":[],"face_keypoints_3d":[],"hand_left_keypoints_3d":[],"hand_right_keypoints_3d":[]},{"person_id":[-1],"pose_keypoints_2d":[326.762,67.0941,0.835013,292.843,116.632,0.809559,318.933,119.205,0.778594,369.854,132.318,0.788894,402.435,142.781,0.68059,265.464,114.053,0.805323,286.307,150.605,0.116523,318.973,138.842,0.0906821,296.697,222.356,0.689089,309.782,217.142,0.62242,399.848,234.028,0.728133,343.702,285.004,0.663077,279.793,224.934,0.628523,299.354,313.71,0.523907,309.83,406.355,0.536063,320.208,59.2032,0.837868,0,0,0,301.959,66.9878,0.822553,0,0,0,313.704,422.031,0.0730525,0,0,0,312.401,412.92,0.314405,325.428,308.449,0.247358,329.384,305.85,0.221445,337.175,286.326,0.50982],"face_keypoints_2d":[],"hand_left_keypoints_2d":[],"hand_right_keypoints_2d":[],"pose_keypoints_3d":[],"face_keypoints_3d":[],"hand_left_keypoints_3d":[],"hand_right_keypoints_3d":[]},{"person_id":[-1],"pose_keypoints_2d":[98.3958,111.449,0.80564,108.758,134.915,0.71748,108.815,131.075,0.731669,98.4143,161.018,0.220633,87.9582,171.464,0.192716,107.481,136.218,0.838919,98.4284,162.378,0.92172,78.8656,180.569,0.834868,107.486,181.862,0.746161,107.496,180.595,0.719531,93.1735,214.482,0.523993,108.794,252.351,0.692249,106.223,181.894,0.798912,110.13,221.018,0.456124,112.725,256.245,0.767063,0,0,0,99.7246,110.094,0.877091,0,0,0,108.776,112.754,0.885137,94.4694,258.912,0.723372,99.6499,262.818,0.717684,117.946,260.209,0.717864,90.5345,257.57,0.508821,93.1701,255.023,0.452858,111.455,254.952,0.324459],"face_keypoints_2d":[],"hand_left_keypoints_2d":[],"hand_right_keypoints_2d":[],"pose_keypoints_3d":[],"face_keypoints_3d":[],"hand_left_keypoints_3d":[],"hand_right_keypoints_3d":[]}]}

  def InputProcesser(self,frame): #deletes irrevelent inputs from openpose and returns 3 arrays:x_vals,y_vals,z_vals with keypoint labels(1~25) corresponding to index+1
    arr = self.frame["people"] #arr is the relevant part of the output in the array [dictionary] format
  #  del arr[0]
    del arr[0]["person_id"] #deletes the irrelevent pts of inputs
    del arr[0]["face_keypoints_2d"]
    del arr[0]["hand_left_keypoints_2d"]
    del arr[0]["hand_right_keypoints_2d"]
    del arr[0]["pose_keypoints_3d"]
    del arr[0]["face_keypoints_3d"]
    del arr[0]["hand_left_keypoints_3d"]
    del arr[0]["hand_right_keypoints_3d"]
    global arr1
    arr1 = arr[0]["pose_keypoints_2d"] 
    del arr1[45:] #we can delete the points we don't need
    #arr1 is an array w/ 3d key pts with order of joints
    #print(arr)
    #print(arr1)
    global x_vals
    global y_vals
    global z_vals

    x_vals=[]
    y_vals=[]
    z_vals=[]

    #runs through the arr1 w/ [x,y,z,x,y,z,x,y,z,...] to turn it into 3 arrays(x,y,z). This means call x_vals[12] for the x_val of the keypoint 13 in this frame.
    for x in range(len(arr1)): 
      if x%3 == 0:
        x_vals.append(arr1[x])
      elif (x-1)%3==0 or x == 1:
        y_vals.append(arr1[x])
      elif (x-2)%3==0 or x == 2:
        z_vals.append(arr1[x])
    #print(x_vals)
    #print(y_vals)
    #print(z_vals)
    return x_vals and y_vals and z_vals


  #finds joint length in 3D by inputting two points
  def JointLengthFinder(self, p1, p2, x_val, y_val, z_val): #input the keypoint label(1-25)
    p1_x_val = x_val[p1] #-2 because there x_vals is 14 long and starts at 0
    p1_y_val = y_val[p1]
    p1_z_val = z_val[p1]
    p2_x_val = x_val[p2]
    p2_y_val = y_val[p2]
    p2_z_val = z_val[p2]
    
    length = math.sqrt((p1_x_val - p2_x_val)**2 + (p1_y_val - p2_y_val)**2 + (p1_z_val - p2_z_val)**2)
    return length #length between two points using distance formula w/ 3d

  def JointLengthFinder2d(self, p1, p2): #input the keypoint label(1-25)
    p1_x_val2 = x_vals[p1]
    p1_y_val2 = y_vals[p1]
    p2_x_val2 = x_vals[p2]
    p2_y_val2 = y_vals[p2]
    
    length2 = math.sqrt((p1_x_val2 - p2_x_val2)**2 + (p1_y_val2 - p2_y_val2)**2)
    return length2 #length between two points using distance formula w/ 3d
 
  #use another dictionary to store all the joint lengths for all of the joint {'1-8':65.46}
  
  def AllBodySegmentLengths(self, frame, x_val, y_val, z_val): #takes in any set of x,y,z arrays #frame is object
    global body_segments
    body_segments = {}
    body_segments['0-1'] = frame.JointLengthFinder(0,1,x_val, y_val, z_val) #neck
    body_segments['1-8'] = frame.JointLengthFinder(1,8,x_val, y_val, z_val) #torso 
    body_segments['1-2'] = frame.JointLengthFinder(1,2,x_val, y_val, z_val) #left shoulder
    body_segments['1-5'] = frame.JointLengthFinder(1,5,x_val, y_val, z_val) #right shoulder
    body_segments['2-3'] = frame.JointLengthFinder(2,3,x_val, y_val, z_val) #left upper arm
    body_segments['5-6'] = frame.JointLengthFinder(5,6,x_val, y_val, z_val) #right upper arm
    body_segments['3-4'] = frame.JointLengthFinder(3,4,x_val, y_val, z_val) #left lower arm
    body_segments['6-7'] = frame.JointLengthFinder(6,7,x_val, y_val, z_val) #right lower arm
    body_segments['8-9'] = frame.JointLengthFinder(8,9,x_val, y_val, z_val) #left hip
    body_segments['8-12'] = frame.JointLengthFinder(8,12,x_val, y_val, z_val) #right hip
    body_segments['9-10'] = frame.JointLengthFinder(9,10,x_val, y_val, z_val) #left thigh
    body_segments['12-13'] = frame.JointLengthFinder(12,13,x_val, y_val, z_val) #right thigh
    body_segments['10-11'] = frame.JointLengthFinder(10,11,x_val, y_val, z_val) #left calf
    body_segments['13-14'] = frame.JointLengthFinder(13,14,x_val, y_val, z_val) #right calf
    #print(body_segments)
    return body_segments

  def AllBodySegmentLengths2(self,frame): #frame is object 
    #finds segment length using x_vals,... --> no need to pass in the x,y,z arrays
    
    global body_segments
    body_segments = {}
    body_segments['0-1'] = frame.JointLengthFinder(0,1,x_vals, y_vals, z_vals) #neck
    body_segments['1-8'] = frame.JointLengthFinder(1,8,x_vals, y_vals, z_vals) #torso 
    body_segments['1-2'] = frame.JointLengthFinder(1,2,x_vals, y_vals, z_vals) #left shoulder
    body_segments['1-5'] = frame.JointLengthFinder(1,5,x_vals, y_vals, z_vals) #right shoulder
    body_segments['2-3'] = frame.JointLengthFinder(2,3,x_vals, y_vals, z_vals) #left upper arm
    body_segments['5-6'] = frame.JointLengthFinder(5,6,x_vals, y_vals, z_vals) #right upper arm
    body_segments['3-4'] = frame.JointLengthFinder(3,4,x_vals, y_vals, z_vals) #left lower arm
    body_segments['6-7'] = frame.JointLengthFinder(6,7,x_vals, y_vals, z_vals) #right lower arm
    body_segments['8-9'] = frame.JointLengthFinder(8,9,x_vals, y_vals, z_vals) #left hip
    body_segments['8-12'] = frame.JointLengthFinder(8,12,x_vals, y_vals, z_vals) #right hip
    body_segments['9-10'] = frame.JointLengthFinder(9,10,x_vals, y_vals, z_vals) #left thigh
    body_segments['12-13'] = frame.JointLengthFinder(12,13,x_vals, y_vals, z_vals) #right thigh
    body_segments['10-11'] = frame.JointLengthFinder(10,11,x_vals, y_vals, z_vals) #left calf
    body_segments['13-14'] = frame.JointLengthFinder(13,14,x_vals, y_vals, z_vals) #right calf
    return body_segments
  


  def Angle1Finder(self, frame, p1, p2): #type 1 angle, forward-facing
    global angle1
    if abs(x_vals[p1] - x_vals[p2]) == 0:
      print("stop")
      angle2 = 0
      return angle2
    else: 
      angle1 = math.degrees(math.atan(abs(abs(y_vals[p1] - y_vals[p2])/abs(x_vals[p1] - x_vals[p2]))))
    #print(angle1)
    return angle1
  
  def Angle2Finder(self, frame, p1, p2): #type 2 angle, sideways
    global angle2
    if abs(y_vals[p1] - y_vals[p2]) == 0:
      angle2 = 0
      return angle2
      print("stop2")
    else:
      angle2 = math.degrees(math.atan(abs(abs(z_vals[p1] - z_vals[p2])/abs(y_vals[p1] - y_vals[p2]))))
    #print(angle2)
    return angle2
  
  def JointSegmentConverter(self, body_part): #returns joint points corresponding with the body segment wanted & stores the joints points in global variable a & b for the next angle finder step
    joint_segment_keys = {
      "neck":[0,1],
      "torso":[1,8],
      "left_shoulder":[1,2],
      "right_shoulder":[1,5],
      "left_upper_arm":[2,3],
      "right_upper_arm":[5,6],
      "left_lower_arm":[3,4],
      "right_lower_arm":[6,7],
      "left_hip":[8,9],
      "right_hip":[8,12],
      "left_thigh":[9,10],
      "right_thigh":[12,13],
      "left_calf":[9,10],
      "right_calf":[13,14]      
      }

    if body_part in joint_segment_keys:
      global a
      global b
      a = joint_segment_keys[body_part][0]
      b = joint_segment_keys[body_part][1]
      return a and b 
    else:
      print("joint segment name is entered incorrectly!")

  def AngleRetriever(self, frame, video_number, angle_type):
    #retrieves the angle w/ specified angle finder and temperarally stores angle in temp_angle
      global temp_angle 
      if angle_type == 1:
        temp_angle = frame.Angle1Finder(frame, a, b) #pass in the points to find the angle for the segments
      elif angle_type == 2:
        temp_angle = frame.Angle2Finder(frame, a, b)
      else:
        print("invalid angle type: angle type must be 1 or 2")
      return temp_angle


  def BodyRatioResizing(self, frame): #kinda useless rn
    ratio = 100.0/(frame.AllBodySegmentLengths2(frame).get('1-8')) #ratio that all key points will multiply to
    global nx_vals #creates new x,y,and z values after multiplied by ratio
    global ny_vals
    global nz_vals
    
    nx_vals=[]
    ny_vals=[]
    nz_vals=[]
    

    for x in x_vals:  #runs through orig. x_vals
      nx_vals.append(x * ratio)
    for y in y_vals:
      ny_vals.append(y * ratio)
    for z in z_vals:
      nz_vals.append(z * ratio)

    #print(frame.AllBodySegmentLengths(frame,nx_vals,ny_vals,nz_vals))
    
    print(frame.AllBodySegmentLengths2(frame))

    #print(nx_vals)
    #print(ny_vals)
    #print(nz_vals)

      
def FileReader(video_number, frame_ct, body_part, angle_type): #for 1 video: runs through all the frames & creates the new files
    global final_angle_array
    final_angle_array = []
    for x in range(frame_ct): #x is the frame number
      #global temp_angle
      #temp_angle = None
      if x < 10:
        x = "0"+str(x)
      else:
        x = str(x)
      filename = "video_0000000000" + x + "_keypoints (" + str(video_number) + ").json"
      with open(filename, "r") as read_file:
        data1 = json.load(read_file)
      body1 = Standardization(data1)
      body1.InputProcesser(body1)
      body1.JointSegmentConverter(body_part)
      body1.AngleRetriever(body1, video_number, angle_type)
      if temp_angle != 0:
        final_angle_array.append(temp_angle)
    #print(final_angle_array)
    global final_vid_angles
    final_vid_angles = {"final_vid_angles": final_angle_array}
    

    return final_angle_array



#FileReader(2,35,"neck",2) #IMPORTANT: frame_count needs to be one higher than the number labeled in the files--> if 34 frames labeled(35 in total when including 0th frame) enter 35! 

def FileWriter(video_number1, frame_ct):
  bodyparts = ["neck",
      "torso",
      "left_shoulder",
      "right_shoulder",
      "left_upper_arm",
      "right_upper_arm",
      "left_lower_arm",
      "right_lower_arm",
      "left_hip",
      "right_hip",
      "left_thigh",
      "right_thigh",
      "left_calf",
      "right_calf"]
  for i in bodyparts:
    FileReader(video_number1,frame_ct, i, 1)
    filename1 = "Vid:" + str(video_number1) +"_BodySeg:_" +str(i)+"_Angle:_1"+".json" #V for video number, S for segment, A for Angle
    with open(filename1, 'w') as json_file:
          json.dump(final_vid_angles, json_file)

    FileReader(video_number1,frame_ct, i, 2)
    filename2 = "Vid:" + str(video_number1) +"_BodySeg:_" +str(i)+"_Angle:_2"+".json"
    with open(filename2, 'w') as json_file:
          json.dump(final_vid_angles, json_file)

    # NEED TO REPEAT FOR VID 2 FileReader(video_number2,frame_ct, i, 2)
  



FileWriter(4,37)
    

#f = open("testcreatefile.json", "w")
#f.write(str(dictionary))
#f.close()


#body2 = Standardization(data1)
#body2.InputProcesser(body2)
#body2.BodyRatioResizing(body2)
#body2.Angle1Finder(body2,8,12)
#body2.Angle2Finder(body2,8,12)

#{"version":1.3,"people":[{"person_id":[-1],"pose_keypoints_2d":[153.791,31.6656,0.806171,154.425,53.0936,0.815349,139.483,53.098,0.726093,111.578,66.7578,0.750836,131.043,62.2042,0.508491,169.375,52.4575,0.753726,190.782,65.4413,0.758756,175.851,59.5813,0.543022,158.309,97.9224,0.553205,149.233,97.9172,0.465784,160.259,141.427,0.157872,162.204,144.035,0.120467,165.46,97.9237,0.543786,162.865,140.784,0.354162,163.498,145.979,0.107874,150.531,28.428,0.822148,157.669,28.4101,0.861121,145.971,32.3218,0.741939,161.568,29.7438,0.758449,0,0,0,0,0,0,163.515,146.625,0.100578,0,0,0,0,0,0,0,0,0]

#different set of inputs from different frames and process them into just arrays --> find angles of each joint segment 


#body = Standardization({"version":1.3,"people":[{"person_id":[-1],"pose_keypoints_2d":[227.422,57.1933,0.807357,223.511,94.3978,0.836523,199.092,96.3215,0.78966,183.361,121.801,0.765163,221.543,123.734,0.409549,247.021,92.4693,0.772991,277.3,118.86,0.825382,238.157,121.775,0.597572,223.546,166.785,0.40645,206.9,165.793,0.385908,167.732,200.047,0.306381,217.641,221.564,0.220226,240.152,167.76,0.36812,226.453,234.278,0.324446,221.521,295.894,0.258676,220.59,51.3234,0.880818,231.294,50.3888,0.933751,207.915,57.1995,0.841758,236.202,52.3695,0.181712,0,0,0,0,0,0,216.672,301.758,0.208005,0,0,0,0,0,0,218.622,219.598,0.104589],"face_keypoints_2d":[],"hand_left_keypoints_2d":[],"hand_right_keypoints_2d":[],"pose_keypoints_3d":[],"face_keypoints_3d":[],"hand_left_keypoints_3d":[],"hand_right_keypoints_3d":[]}]})

#body.AllBodySegmentLengths(body,x_vals,y_vals,z_vals)
#body.AllBodySegmentLengths2(body)
#print(body.AllBodySegmentLengths().get('1-8'))

#body.InputProcesser(body)
#body.AllBodySegmentLengths2(body)
#body.BodyRatioResizing(body)
#
#for x
#vids=[2]

def RetrieveAngle(video_number, joint_name, angle_type, frame):
  filename = "Vid:" + str(video_number) + "_BodySeg:_" + joint_name + "_Angle:_" + str(angle_type) + ".json" 
  #filename = "video_0000000000" + joint + "_keypoints (" + str(video_number) + ").json"
  with open(filename, "r") as read_file:
    data = json.load(read_file)
  angle = data["final_vid_angles"][frame]
  #print(angle)
  return angle

#RetrieveAngle(2,"left_hip",1,1)

def AngleDifference(a1,a2):
  difference = a1 - a2
  print("Your pose during frame.. is", difference ,"degrees off")
  return difference

def Commander(frame_matches, video_number1, video_number2):
  joint_segment_keys = {
      "neck":[0,1],
      "torso":[1,8],
      "left_shoulder":[1,2],
      "right_shoulder":[1,5],
      "left_upper_arm":[2,3],
      "right_upper_arm":[5,6],
      "left_lower_arm":[3,4],
      "right_lower_arm":[6,7],
      "left_hip":[8,9],
      "right_hip":[8,12],
      "left_thigh":[9,10],
      "right_thigh":[12,13],
      "left_calf":[9,10],
      "right_calf":[13,14]      
      }
  #vid1_matches = frame_matches[0]
  #vid2_matches = frame_matches[1]
  angle_types = ["1","2"]
  final_difference = []
  for index in range(len(frame_matches[0])): #goes through the first video to compare the 2nd video to the first
    temp2 = []
    for atype in angle_types:
      temp1 = []
      for joint in joint_segment_keys:
        print(RetrieveAngle(video_number1, joint, atype, frame_matches[0][index]))
        print(RetrieveAngle(video_number2, joint, atype, frame_matches[1][index]))
        temp1.append(AngleDifference(RetrieveAngle(video_number1, joint, atype, frame_matches[0][index]), RetrieveAngle(video_number2, joint, atype, frame_matches[1][index])))
      
      temp2.append(temp1)
    final_difference.append(temp2)
  print (final_difference)
  return final_difference
  
Commander([[1,2,3,4,5,5,6,7,8,9],[1,2,3,4,5,5,6,7,8,9]],3,4)
        

#difference for angles for frames

def AngleFileReader(video_number, joint, angle_type): #reads the file that store the angles at each frame for 1 JointSegmentConverter
  filename = "Vid:" + str(video_number) + "_BodySeg:_" + str(joint) + "_Angle:_" + str(angle_type) + ".json" 
  #filename = "video_0000000000" + joint + "_keypoints (" + str(video_number) + ").json"
  with open(filename, "r") as read_file:
    data = json.load(read_file)
  data1 = data["final_vid_angles"]
  #print(data1)
  return data1 #returns the angles from all the frames for that joint in an array with the index corresponding to the frames


def PercentError(a1, a2):
  if a2 == 0:
    print("Error: angle 0 is 0 :/") 
    return
  error = (abs(a1 - a2)/2)*100
  print("Your pose during fram.. is",error,"% off")

  return error



def OrientationChecker():
  pass

def ActualFeedback():
  pass
        